package rars.riscv.instructions;

import rars.ProgramStatement;
import rars.assembler.DataTypes;
import rars.riscv.hardware.ControlAndStatusRegisterFile;
import rars.riscv.hardware.FloatingPointRegisterFile;
import rars.riscv.hardware.RegisterFile;
import rars.riscv.BasicInstruction;
import rars.riscv.BasicInstructionFormat;

/*
Copyright (c) 2017,  Benjamin Landers

Developed by Benjamin Landers (benjaminrlanders@gmail.com)

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject
to the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR
ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

(MIT license, http://www.opensource.org/licenses/mit-license.html)
 */

public class FCVTWUS extends BasicInstruction {
    public FCVTWUS() {
        super("fcvt.wu.s t1, f1", "Convert unsinged integer from float: Assigns the value of f1 (rounded) to t1",
                BasicInstructionFormat.I_FORMAT, "1100000 00001 sssss " + Floating.ROUNDING_MODE + " fffff 1010011");
    }

    public void simulate(ProgramStatement statement) {
        int[] operands = statement.getOperands();
        float in = FloatingPointRegisterFile.getFloatFromRegister(operands[1]);
        if (Float.isNaN(in)) {
            ControlAndStatusRegisterFile.orRegister("fcsr", 0x10); // Set invalid flag
            RegisterFile.updateRegister(operands[0], DataTypes.MAX_WORD_VALUE);
        } else if (in < 0) {
            ControlAndStatusRegisterFile.orRegister("fcsr", 0x10); // Set invalid flag
            RegisterFile.updateRegister(operands[0], 0);
        } else if (in > (DataTypes.MIN_WORD_VALUE & 0xFFFFFFFFL)) {
            ControlAndStatusRegisterFile.orRegister("fcsr", 0x10); // Set invalid flag
            RegisterFile.updateRegister(operands[0], DataTypes.MIN_WORD_VALUE);
        } else if (in < DataTypes.MAX_WORD_VALUE) {
            RegisterFile.updateRegister(operands[0], Math.round(in));
        } else {
            in -= DataTypes.MAX_WORD_VALUE;
            RegisterFile.updateRegister(operands[0], Math.round(in) + DataTypes.MAX_WORD_VALUE);
        }
    }
}